import java.util.Scanner;

public class index {

    public static void categori(){


        Scanner menu = new Scanner(System.in);
        String cate = new String();
        cate = menu.nextLine();

        switch(cate){
            case "한식":
                System.out.println("한식메뉴를 추천해드리겠습니다.");
                korea();
                break;
            case "중식":
                System.out.println("중식메뉴를 추천해드리겠습니다.");
                china();
                break;
            case "일식":
                System.out.println("일식메뉴를 추천해드리겠습니다.");
                japen();
                break;
            case "양식":
                System.out.println("양식메뉴를 추천해드리겠습니다.");
                western();
                break;
        }
    }
    public static void korea(){
        System.out.println("한식메뉴");
    }
    public static void china(){
        System.out.println("중식메뉴");
    }
    public static void japen(){
        System.out.println("일식메뉴");
    }
    public static void western(){
        System.out.println("양식");
    }


    public static void main(String[] args) {
        categori();
    }
}
