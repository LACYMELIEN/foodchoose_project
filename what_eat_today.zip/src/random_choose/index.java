
package random_choose;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.sql.*;

public class index {
    static Random random = new Random();
    static int random_data = 0;
    static Scanner menu = new Scanner(System.in);
    static String cate;
    static int cnt = 0;
    static int lport;
    static String rhost;
    static int rport;
    static String changed;
    static ResultSet countting;
    static ArrayList<UserBean> menu_list = new ArrayList<UserBean>();
    static String cate_name;

    public static void categori() {
        cate = menu.nextLine();

        switch (cate) {
            case "한식":
                changed = "Korea";
                cate_name = "한식";
                System.out.println("한식메뉴를 추천해드리겠습니다.");
                select();
                break;
            case "중식":
                changed = "China";
                cate_name = "중식";
                System.out.println("중식메뉴를 추천해드리겠습니다.");
                select();
                break;
            case "일식":
                changed = "Japen";
                cate_name = "일식";
                System.out.println("일식메뉴를 추천해드리겠습니다.");
                select();
                break;
            case "양식":
                changed = "Western";
                cate_name = "양식";
                System.out.println("양식메뉴를 추천해드리겠습니다.");
                select();
                break;
            default:
                System.out.println("잘못 입력 하셨습니다.");
        }

        menu.close();
    }

    public static void go() {
        String user = "hojin";
        String password = "abc1234#";
        String host = "218.144.98.116";
        int port = 22;
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession(user, host, port);
            lport = 3927;
            rhost = "127.0.0.1";
            rport = 3927;
            session.setPassword(password);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            int assinged_port = session.setPortForwardingL(lport, rhost, rport);
        } catch (Exception e) {
        }
    }

    public static void select() {
        try {
            go();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Connection con = null;
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://" + rhost + ":" + lport + "/";
        String db = "menu";
        String dbUser = "project";
        String dbPasswd = "project!39#";
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url + db, dbUser, dbPasswd);
            try {
                Statement st = con.createStatement();
                ResultSet rs = null;
                String sql = "select name from " + changed;
                rs = st.executeQuery(sql);

                while (rs.next()) {
                    UserBean bean = new UserBean();
                    bean.setname(rs.getString("name"));
                    menu_list.add(bean);
                }

                random_data = random.nextInt(menu_list.size());
                System.out.println(" ===== 오늘의 "+ cate_name +" 추천 메뉴는 ?? =====");
                System.out.println("===== " + menu_list.get(random_data).getname() + " =====");

//
//                for(int i =0; i<menu_list.size(); i++){
//                    System.out.println("테스트"+menu_list.get(i).getname());
//            }

            } catch (SQLException s) {
                System.out.println("SQL statement is not executed!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        categori();

    }

}
