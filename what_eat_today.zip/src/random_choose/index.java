
package random_choose;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.sql.*;

public class index {
    static Random random = new Random();
    static int random_data = 0;
    static Scanner menu = new Scanner(System.in);
    static String cate;
    static int cnt = 0;
    static int lport;
    static String rhost;
    static int rport;
    static String changed;

    public static void categori() {
        cate = menu.nextLine();

        switch (cate) {
            case "한식":
                changed = "Korea";
                System.out.println("한식메뉴를 추천해드리겠습니다.");
                korea();
                break;
            case "중식":
                changed = "China";
                System.out.println("중식메뉴를 추천해드리겠습니다.");
                china();
                break;
            case "일식":
                changed = "Japen";
                System.out.println("일식메뉴를 추천해드리겠습니다.");
                japen();
                break;
            case "양식":
                changed = "Western";
                System.out.println("양식메뉴를 추천해드리겠습니다.");
                western();
                break;
            default:
                System.out.println("잘못 입력 하셨습니다.");
        }

        menu.close();
    }

    public static void korea() {
        random_data = random.nextInt(7);
        String[] arr = {"비빔밥", "불고기", "황태구이", "차돌박이 부추무침", "잡채", "등비갈찜"};
        System.out.println(" ===== 오늘의 한식 추천 메뉴는 ?? =====");
        System.out.println("===== " + arr[random_data] + " =====");
    }

    public static void china() {
        random_data = random.nextInt(7);
        String[] arr = {"짜장면", "짬뽕", "볶음밥", "마라탕", "마라샹궈", "양꼬치", "우육면"};
        System.out.println(" ===== 오늘의 중식 추천 메뉴는 ?? =====");
        System.out.println("===== " + arr[random_data] + " =====");
    }

    public static void japen() {
        random_data = random.nextInt(5);
        String[] arr = {"타코야끼", "오꼬노미야끼", "돈까스 덮밥", "미소 라면", "돈코츠 된장 라면"};
        System.out.println(" ===== 오늘의 일식 추천 메뉴는 ?? =====");
        System.out.println("===== " + arr[random_data] + " =====");
    }

    public static void western() {
        random_data = random.nextInt(6);
        String[] arr = {"홍합 스튜", "치킨", "카나페", "샌드위치", "두부셀러드", "로제파스타"};
        System.out.println(" ===== 오늘의 양식 추천 메뉴는 ?? =====");
        System.out.println("===== " + arr[random_data] + " =====");
    }

    public static void go() {
        String user = "hojin";
        String password = "abc1234#";
        String host = "218.144.98.116";
        int port = 22;
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession(user, host, port);
            lport = 3927;
            rhost = "127.0.0.1";
            rport = 3927;
            session.setPassword(password);
            session.setConfig("StrictHostKeyChecking", "no");
            System.out.println("Establishing Connection...");
            session.connect();
            int assinged_port = session.setPortForwardingL(lport, rhost, rport);
            System.out.println("localhost:" + assinged_port + " -> " + rhost + ":" + rport);
        } catch (Exception e) {
            System.err.print(e);
        }
    }

    public static void select() {
        try {
            go();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        System.out.println("An example for updating a Row from Mysql Database!");
        Connection con = null;
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://" + rhost + ":" + lport + "/";
        String db = "menu";
        String dbUser = "project";
        String dbPasswd = "project!39#";
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url + db, dbUser, dbPasswd);
            try {
                Statement st = con.createStatement();
                ResultSet rs = null;
                String sql = "select name from " + changed;
                rs = st.executeQuery(sql);

                while (rs.next()) {
                    String name = rs.getString("name");
                    System.out.println(name);
                }

            } catch (SQLException s) {
                System.out.println("SQL statement is not executed!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        categori();
        select();

    }

}
