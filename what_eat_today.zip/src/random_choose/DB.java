package random_choose;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.sql.*;
import java.util.Random;
import java.util.Scanner;

public class DB {
        static Random random = new Random();
        static int random_data = 0;
        static Scanner menu = new Scanner(System.in);
        static String cate;
        static int cnt = 0;
        static int lport;
        static String rhost;
        static int rport;

        public static void go() {
            String user = "hojin";
            String password = "abc1234#";
            String host = "218.144.98.116";
            int port = 22;
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(user, host, port);
                lport = 3927;
                rhost = "127.0.0.1";
                rport = 3927;
                session.setPassword(password);
                session.setConfig("StrictHostKeyChecking", "no");
                System.out.println("Establishing Connection...");
                session.connect();
                int assinged_port = session.setPortForwardingL(lport, rhost, rport);
                System.out.println("localhost:" + assinged_port + " -> " + rhost + ":" + rport);
            } catch (Exception e) {
                System.err.print(e);
            }
        }

        public static ResultSet select(){
            try {
                go();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            System.out.println("An example for updating a Row from Mysql Database!");
            Connection con = null;
            String driver = "com.mysql.jdbc.Driver";
            String url = "jdbc:mysql://" + rhost + ":" + lport + "/";
            String db = "menu";
            String dbUser = "project";
            String dbPasswd = "project!39#";
            try {
                Class.forName(driver);
                con = DriverManager.getConnection(url + db, dbUser, dbPasswd);
                try {
                    Statement st = con.createStatement();
                    ResultSet rs = null;
                    String sql = "select name from " +cate;
                    rs = st.executeQuery(sql);

                    while (rs.next()){
                        String name = rs.getString("name");
                        System.out.println(name);
                    }

                } catch (SQLException s) {
                    System.out.println("SQL statement is not executed!");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    public static void main(String[] args) throws SQLException {

        select();
    }
}
