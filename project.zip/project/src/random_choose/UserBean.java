package random_choose;

public class UserBean {
    String name;
    public String getname(){
        return name;
    }
    public void setname(String name) {
        this.name = name;
    }
}
