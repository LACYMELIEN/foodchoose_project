import java.util.*;

public class Index {
    static Random random = new Random();
    static int random_data = 0;
    public static void categori(){
        Scanner menu = new Scanner(System.in);
        String cate;
        cate = menu.nextLine();

        switch(cate){
            case "한식":
                System.out.println("한식메뉴를 추천해드리겠습니다.");
                korea();
                break;
            case "중식":
                System.out.println("중식메뉴를 추천해드리겠습니다.");
                china();
                break;
            case "일식":
                System.out.println("일식메뉴를 추천해드리겠습니다.");
                japen();
                break;
            case "양식":
                System.out.println("양식메뉴를 추천해드리겠습니다.");
                western();
                break;
            default:
                System.out.println("잘못 입력 하셨습니다.");
        }

        menu.close();
    }
    public static void korea(){
        random_data = random.nextInt(7);
        String[] arr = {"비빔밥","불고기","황태구이","차돌박이 부추무침","잡채","등갈비찜"};
        System.out.println(" ===== 오늘의 한식 추천 메뉴는 ?? =====");
        System.out.println("===== " + arr[random_data] + " =====");
    }
    public static void china(){
        random_data = random.nextInt(7);
        String[] arr = {"짜장면","짬뽕","볶음밥","마라탕","마라샹궈","양꼬치","우육면"};
        System.out.println(" ===== 오늘의 중식 추천 메뉴는 ?? =====");
        System.out.println("===== " + arr[random_data] + " =====");
    }
    public static void japen(){
        random_data = random.nextInt(5);
        String[] arr = {"타코야끼","오꼬노미야끼","돈까스 덮밥","미소 라면","돈코츠 된장 라면"};
        System.out.println(" ===== 오늘의 일식 추천 메뉴는 ?? =====");
        System.out.println("===== " + arr[random_data] + " =====");
    }
    public static void western(){
        random_data = random.nextInt(6);
        String[] arr = {"홍합 스튜","치킨","카나페","샌드위치","두부셀러드","로제파스타"};
        System.out.println(" ===== 오늘의 양식 추천 메뉴는 ?? =====");
        System.out.println("===== " + arr[random_data] + " =====");
    }

    public static void main(String[] args) {

        categori();
    }
}
